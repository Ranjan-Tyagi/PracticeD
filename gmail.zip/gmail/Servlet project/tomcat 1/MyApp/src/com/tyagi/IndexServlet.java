package com.tyagi;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class IndexServlet
 */
@WebServlet("/register")
public class IndexServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public IndexServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		super.destroy();
		System.out.println("Servlet is now Dead!!!");
	}

	@Override
	public void init() throws ServletException {
		// TODO Auto-generated method stub
		super.init();
		System.out.println("Servlet is powered by Tomcat....,");
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		out.println("<!DOCTYPE html><head><title>Welcome Ranjan you are Great!!</title></head>");
		out.println("<body bgcolor=lightgreen><h1>Hi Tyagi!! ...Happy Holi!!</h1>"
		+ request.getRemoteHost());
		String name=request.getParameter("User");
		String age1=request.getParameter("Uage");
		int age=0;
		
		try {
			age=Integer.parseInt(age1);
		} catch (NumberFormatException e) {
			out.println("<h3>Invalid Age!!</h3><br/>");
		}
		
		String[] langs=request.getParameterValues("ulang");
		out.println("Details accepted are: ");
		out.println("   Name:    "+name+"   Age:   "+age+"    Choosen Colors are:     ");
		for(String lang:langs)
		{
			out.println(lang+"     ");
		}
		out.println("</body></html>");
		out.close();
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
