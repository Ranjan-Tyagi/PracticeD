export interface Employee {
    empId: number
    firstName: string
    lastName: string
    doj: Date
    dob: Date
    salary: number
}
