import { Component, OnInit, DoCheck } from '@angular/core';
import {ActivatedRoute} from '@angular/router';


@Component({
  selector: 'app-contactus',
  templateUrl: './contactus.component.html',
  styleUrls: ['./contactus.component.css']
})
export class ContactusComponent implements OnInit {

   contact:string;
   ctype: string;

   constructor(private rout: ActivatedRoute) {
     rout.params.subscribe(params => { this.ctype = params['ctype'] })
     console.log("Received parameter: " + this.ctype);
   }

  ngOnInit() {
    
  }

  ngDoCheck() {
    switch (this.ctype) {
      case "phone":
        this.contact = "8660987654";
        break;
      case "mail":
        this.contact = "tranjan505@gmail.com";
        break;
      default:
        this.contact = "Please specify contact type!";
    }
  }
}
