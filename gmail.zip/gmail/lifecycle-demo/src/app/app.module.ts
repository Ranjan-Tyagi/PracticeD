import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import {Routes, RouterModule } from '@angular/router';
import { HashLocationStrategy, LocationStrategy } from '@angular/common';

import { AppComponent } from './app.component';
import { ContactusComponent } from './contactus/contactus.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { VacanciesComponent } from './vacancies/vacancies.component';

const routes: Routes=[
  { path:'contactus/:ctype' ,component:ContactusComponent },
  { path:'aboutus' ,component: AboutusComponent },
  { path:'vacancies' ,component:VacanciesComponent}

]


@NgModule({
  declarations: [
    AppComponent,
    ContactusComponent,
    AboutusComponent,
    VacanciesComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forRoot(routes),
    HttpModule
  ],
  providers: [   { provide: LocationStrategy, useClass: HashLocationStrategy }   ],
  bootstrap: [AppComponent]
})
export class AppModule { }
