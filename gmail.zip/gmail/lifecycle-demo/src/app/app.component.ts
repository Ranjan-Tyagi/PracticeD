import { Component } from '@angular/core';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  title = 'app works!';

  constructor(fb: FormBuilder) {
    // this.formControl = fb.group({
    //   'Username': ['', Validators.required],
    //   'Password':['',[Validators.min(8),
    //   Validators.max(16)]]
    // });
  }

  formControl: FormGroup;
  Username: String;
  Password: String;

ngOnInit()
{
  console.log("Component Initialized!!!")
}

ngOnChanges()
{
  console.log("Component Changes!!!")
}


ngOnDestroy()
{
  console.log("Component prepared to Destroy!!!")
}

ngDoCheck()
{
  console.log("Component check...")
}
}