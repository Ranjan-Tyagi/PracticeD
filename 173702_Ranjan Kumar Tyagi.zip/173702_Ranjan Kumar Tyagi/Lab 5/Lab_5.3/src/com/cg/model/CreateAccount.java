package com.cg.model;

public class CreateAccount extends Account {
	public CreateAccount(long accNum, double balance, Person accHolder) {
		// TODO Auto-generated constructor stub
		super(accNum,balance,accHolder);
	}
}
