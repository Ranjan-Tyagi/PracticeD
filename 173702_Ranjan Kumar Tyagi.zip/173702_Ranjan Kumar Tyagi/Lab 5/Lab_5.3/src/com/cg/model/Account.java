package com.cg.model;

public abstract class Account {

	long accNum;
	double balance;
	Person accHolder;
	
	public Account(long accNum, double balance, Person accHolder) {
		super();
		this.accNum = accNum;
		this.balance = balance;
		this.accHolder = accHolder;
	}
	
	public long getAccNum() {
		return accNum;
	}
	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public Person getAccHolder() {
		return accHolder;
	}
	public void setAccHolder(Person accHolder) {
		this.accHolder = accHolder;
	}
	
	public void deposit(double amount)
	{
		double deposit=balance+amount;
		System.out.println("Rs."+deposit);
	}
	
	public void withdraw(double amount)
	{   if(balance-amount>=500)
	{
		balance=balance-amount;
		System.out.println("Rs."+balance);
	}
		else
		{
			System.out.println("Minimum Balance is not Maintained.........Withdrawl unsucessful");
		}
	}
	
	public double getBalance(double amount)
	{
		double getBalance=balance;
		return balance;
	}
	
	
	public void getDetails()
	{
		System.out.println("Account number is:"+accNum);
		System.out.println("Account Balance is:"+balance);
		System.out.println("Account holder name is:"+accHolder);
		
	}

	@Override
	public String toString() {
		return "Account [accNum=" + accNum + ", balance=" + balance
				+ ", accHolder=" + accHolder + "]";
	}
	
}
