package com.cg.eis.pl;

import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.service.Service;

public class EmployeeMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		@SuppressWarnings("resource")
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of Employees");
		int n=sc.nextInt();
		Employee e[]=new Employee[n];
		Service s=new Service();
		for(int i=0;i<n;i++)
			e[i]=s.employeeDetails();
		for(int i=0;i<n;i++)
			e[i].setInsuranceScheme(s.insuranceScheme(e[i]));
		System.out.println("Employee Details are:");
		
		for(int i=0;i<n;i++)
			s.showDetails(e[i]);
		
		
	}

/*    1
e1
50000
Manager  

2
e2
35000
Programmer

3
e3
15000
System_Associate

4
e4
4000
Clerk

5
e5
6600000
tyagi
*/


}
