package com.cg.main;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class DateCheckTest {

	DateCheck d;
	static int i=1;
	
	@Before
	public void setUp()
	{
		System.out.println("Test "+i+" Started");
		d=new DateCheck(22,2,2000);
	}
	@After
	public void tearDown()
	{
		System.out.println("Test "+i+" Ended");
		d=null;
		i++;
	}
	@Test
	public void testGetDay() {
		assertEquals(22, d.getDay());
	}
	
	@Test
	public void testGetMonth() {
		assertEquals(2, d.getMonth());
	}
	
	@Test
	public void testGetYear() {
		assertEquals(2000, d.getYear());
	}
	
	@Test
	public void testSetDay() {
		d.setDay(22);
		assertEquals(22,d.getDay());
		
	}
	
	@Test
	public void testSetMonth() {
		d.setMonth(2);
		assertEquals(2,d.getMonth());
		}
	
	@Test
	public void testSetYear() {
		d.setYear(2001);
		assertEquals(2001,d.getYear());
		}

}
