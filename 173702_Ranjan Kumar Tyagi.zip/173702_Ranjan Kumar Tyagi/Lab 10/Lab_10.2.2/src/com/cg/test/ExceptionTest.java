package com.cg.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.cg.eis.exception.EmployeeException;

public class ExceptionTest {

	@Test(expected=EmployeeException.class)
	public void test() throws EmployeeException {
		ExceptionCheck e=new ExceptionCheck();
		assertEquals(false,e.checkSalary(2000));
	}

}
