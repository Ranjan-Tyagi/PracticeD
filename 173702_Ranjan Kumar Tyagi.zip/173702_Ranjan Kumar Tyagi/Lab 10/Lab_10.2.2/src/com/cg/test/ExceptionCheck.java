package com.cg.test;

import com.cg.eis.exception.EmployeeException;

public class ExceptionCheck {

	public boolean checkSalary(double salary) throws EmployeeException
	{
		boolean f=true;
		if(salary<3000)
			throw new EmployeeException(salary,"Salary should be more than 3000");
		else
			f=false;
		return f;
	}
}
