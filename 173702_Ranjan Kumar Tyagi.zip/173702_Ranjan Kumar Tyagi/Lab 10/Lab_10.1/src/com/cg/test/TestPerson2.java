package com.cg.test;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestPerson2 {

	@Test
	public void testGetFullName() {
		System.out.println("from TestPerson2");
		Person per=new Person("Robert","King");
		assertEquals("Robert King",per.getFullName());
	}
	
	@Test
	public void testNullsInName() {
		System.out.println("from TestPerson2 testing expectations");
	//	Person per1=new Person(null,null);

}
}
