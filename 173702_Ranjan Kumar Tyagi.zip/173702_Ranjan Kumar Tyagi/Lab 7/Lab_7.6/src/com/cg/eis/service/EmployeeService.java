package com.cg.eis.service;

import com.cg.eis.bean.Employee;

public interface EmployeeService {

	public Employee employeeDetails();
	public String insuranceScheme(Employee e);
	public void searchForEmployee(String is);
	public boolean deleteEmployee(int id);
	public void showDetails(Employee e);
	public void showSortedList();
	
}
