package com.cg.eis.service;

import java.util.Scanner;

import com.cg.eis.bean.Employee;

public class Service {
	
	
public Employee employeeDetails()
	{
		System.out.println("Enter ID,Name,Salary and Designationof employee");
		Scanner sc=new Scanner(System.in);
		return new Employee(sc.nextInt(),sc.next(),(long) sc.nextDouble(),sc.next());
	}


public String toString() {
	return "Service [employeeDetails()=" + employeeDetails() + ", getClass()="
			+ getClass() + ", hashCode()=" + hashCode() + ", toString()="
			+ super.toString() + "]";
}

public String insuranceScheme(Employee e)
{
	if(e.getSalary()>=40000 && e.getDesignation().equals("Manager"))
		
		return "Scheme A";
	 
		
	else if(e.getSalary()>=20000 && e.getDesignation().equals("Programmer"))
		return "Scheme B";
	
	else if(e.getSalary()>=5000 && e.getDesignation().equals("System_Associate"))
		return "Scheme C";
	
	else if(e.getSalary()<5000 && e.getDesignation().equals("Clerk"))
		return "No Scheme ";
	
	else
		return "Invalid Input ";
}

public void showDetails(Employee e)
{
System.out.println(e.getId());
System.out.println(e.getName());
System.out.println(e.getSalary());
System.out.println(e.getDesignation());
System.out.println(e.getInsuranceScheme());
}
}
