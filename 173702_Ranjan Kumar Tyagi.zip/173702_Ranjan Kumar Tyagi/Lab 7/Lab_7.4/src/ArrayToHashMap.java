import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;


public class ArrayToHashMap {
	public  Map<String, Integer> arrayToHash(int a[])
	{
		Map<String,Integer> m=new HashMap<>();
		for(int i=0;i<a.length;i++)
			m.put(String.valueOf(new Integer(a[i])), new Integer(a[i]*a[i]));
		return m;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		@SuppressWarnings("resource")
		Scanner sc=new Scanner(System.in);
		Map<String,Integer> m=new HashMap<>();
		 System.out.println("Enter number of elements of Array");
		 int n=sc.nextInt();
		 int a[]=new int [n];
		 System.out.println("Enter elements of array:");
		 for(int i=0;i<n;i++)
			 a[i]=sc.nextInt();
		 ArrayToHashMap ath=new ArrayToHashMap();
		 m=ath.arrayToHash(a);
		 System.out.println("Number Squares Map is:");
		 @SuppressWarnings("rawtypes")
		Set set=m.entrySet();
		 
		 @SuppressWarnings("rawtypes")
		Iterator i=set.iterator();
		 while(i.hasNext())
		 {
			 @SuppressWarnings("rawtypes")
			Map.Entry me=(Map.Entry) i.next();
			 System.out.println(me.getKey()+":"+me.getValue());
		  }

	}

}
