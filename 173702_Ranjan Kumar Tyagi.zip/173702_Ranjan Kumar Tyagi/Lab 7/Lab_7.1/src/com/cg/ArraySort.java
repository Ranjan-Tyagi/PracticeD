package com.cg;

import java.util.Scanner;

public class ArraySort {

	public static int[] getSorted(int arr[])
	{
		System.out.println("\n Elements in Array: ");
		for(int a:arr)
		{
			System.out.println(a);
		}
		System.out.println("\n Reversed array: ");
		for(int i=0;i<arr.length;i++)
		{
			int num=arr[i],reversed=0;
			while(num!=0)
			{
				int digit=num%10;
				reversed=reversed*10+digit;
				num=num/10;
			}
			arr[i]=reversed;
		}
		for(int a:arr)
		{
			System.out.println(a+"\t");
		}
		for(int i=0;i<arr.length;i++)
		{
			for(int j=0;j<arr.length-1;j++)
			{
				int temp=0;
				if(arr[j+1]<arr[j])
				{
					temp=arr[j];
					arr[j]=arr[j+1];
					arr[j+1]=temp;
				}
			}
		}
		return arr;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
   Scanner sc=new Scanner(System.in);
   System.out.println("Enter the number of Elements");
   int n=sc.nextInt();
   int arr[]=new int[n];
   for(int i=0;i<n;i++)
   {
	   System.out.println("Enter element"+(i+1)+":");
	   arr[i]=sc.nextInt();
   }
   arr=getSorted(arr);
   System.out.println("\n Sorted array:");
   for(int a:arr)
   {
      System.out.println(a+"\t");
  
   }
   sc.close();
	}

}
