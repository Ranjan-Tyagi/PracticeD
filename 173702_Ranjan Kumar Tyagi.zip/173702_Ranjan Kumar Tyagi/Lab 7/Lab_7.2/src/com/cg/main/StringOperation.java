package com.cg.main;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class StringOperation {
	
	public String method1(String s1,String s2)
	{
		String p="";
		for(int i=0;i<s1.length();i++)
			if(i%2!=0)
				p+=s2;
			else
				p+=s1.charAt(i);
		return p;
	}
	
	public String method2(String s1,String s2)
	{
		if((s1.length()-(s1.replace(s2, "")).length())/s2.length()>0)
		{
		String p="",ns="";
		for(int i=s2.length()-1;i>=0;i--)
			p+=s1.charAt(i);
		for(int i=0;i<s1.length();i++)
		{
			if(i==s1.lastIndexOf(s2))
			{
				ns+=p;
				i+=s2.length();
			}
			else 
				ns=ns+s1.charAt(i++);
		}
			return ns;
		
	}
	else
		return s1+s2;
	}
public String method3(String s1,String s2)
{
	if((s1.length()-(s1.replace(s2, "")).length())/s2.length()>1)
		s1=s1.replace(s2,"");
	return s1;
}

public String method4(String s1,String s2)
{
	if(s1.length()%2==0)
		return s1=s2.substring(0,s2.length()/2)+s1+s2.substring(s2.length()/2,s2.length());
	else
		return s1=s2.substring(0,s2.length()/2+1)+s1+s2.substring(s2.length()/2+1,s2.length());
}

public String method5(String s1,String s2)
{
String p="";
for(int i=0;i<s1.length();i++)
	if(s2.contains(String.valueOf(s1.charAt(i))))
		p+="*";else
			p+=s1.charAt(i);
return p;
}

public StringOperation()
{
	
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc=new Scanner(System.in);
		StringOperation so=new StringOperation();
		List<String> l=new ArrayList<String>();
		System.out.println("Enter Bigger String");
		String s1=sc.nextLine();
		System.out.println("Enter Smaller String");
		String s2=sc.nextLine();
		l.add(so.method1(s1,s2));
		l.add(so.method2(s1,s2));
		l.add(so.method3(s1,s2));
		l.add(so.method4(s1,s2));
		l.add(so.method5(s1,s2));
		for(Object o:l)
			System.out.println(o);
	}

}
