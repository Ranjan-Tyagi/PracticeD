package com.cg;



public class ThreadSleep {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TRunnable tr=new TRunnable();
		Thread hello=new Thread(new TRunnable());
		hello.start();
	}
}

