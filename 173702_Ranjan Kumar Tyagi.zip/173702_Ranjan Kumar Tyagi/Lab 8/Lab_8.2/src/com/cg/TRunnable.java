package com.cg;

public class TRunnable implements Runnable {

	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		for(int j=0;j<4;j++)
		{
	        for (int i=1;i<=10;i++)
	        {
	            //Pause for 4 seconds
	            try
	            {
					Thread.sleep(1000);
				} 
	            catch (InterruptedException exp)
	            {
					// TODO Auto-generated catch block
					System.err.println(exp.getMessage());
				}
	            //Print a message
	            System.out.println(i);
	        }
	    }
	}
    
}
