package com.cg.main;

import com.cg.runnable.ShoppingRunnable;

public class ShoppingMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ShoppingRunnable s=new ShoppingRunnable();
		Thread t1=new Thread(s,"Number");
		t1.start();
		
		
		try {
			t1.join();
			
		} catch (InterruptedException e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}
		
	s.bill();

	}

}
/*pen 5
register 50
mobile 13000
mouse 500
machine 12832*/