package com.cg.runnable;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

public class ShoppingRunnable implements Runnable{
	
	HashMap <String,Integer> h=new HashMap<>();
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("List your products and enter their price and press end to see the bill");
		while(true)
		{
			
			String s=sc.next();
			if(s.equals("end"))
				break;
			h.put(s,sc.nextInt());
			
		}
	}
        public void bill()
        {
        	int sum=0;
        	Set set=h.entrySet();
        	Iterator i=set.iterator();
        	while(i.hasNext())
        	{
        		Map.Entry me=(Map.Entry) i.next();
        		sum+=(int) me.getValue();
        	}
        	System.out.println("Total Bill is:" +sum);
        	System.out.println("Would you like to pay it by Cash or Card ");
        }
}
