package com.cg.main;

import com.cg.runnable.FactorialOfNumberRunnable;

public class ThreadRunMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FactorialOfNumberRunnable f=new FactorialOfNumberRunnable();
		Thread t1=new Thread(f,"Number");
		Thread t2=new Thread(f,"Factorial");
		
		t1.start();
		t2.start();
		
		try {
			t1.join();
			t2.join();
		} catch (InterruptedException e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}
		
		System.out.println("All thread are dead exiting to the main");
		

	}

}
