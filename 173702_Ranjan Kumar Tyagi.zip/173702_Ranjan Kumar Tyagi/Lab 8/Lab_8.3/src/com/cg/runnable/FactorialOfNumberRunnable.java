package com.cg.runnable;

import java.util.Random;

public class FactorialOfNumberRunnable implements Runnable{

	boolean valueSet=false;
	int rnum=0;
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		
		String option=Thread.currentThread().getName();
		for(int i=0;i<10;i++)
		{
			if(option=="Factorial")
				calFactorial(); //producing new balance
			
			if(option=="Number")
				genRandomNumber(); //consuming balance
		}
	}
	 
	public synchronized void calFactorial()
	{
		if(!valueSet)
		{
			try
			
			{
				wait();
			
			}
			catch(InterruptedException e)
			{
				e.printStackTrace();
			}
		}
		else
		{
			System.out.println("Thread start:::"+Thread.currentThread().getName());
			System.out.println(rnum+"'s Factorial = "+factorial(rnum));
			System.out.println("Thread Ended:::"+Thread.currentThread().getName());
			System.out.println("____________________________________________________");
			valueSet=false;
			notify();
		}
	}
	private int factorial(int num)
	{
		if(num==1||num==0)
			return 1;
		return num*factorial(num-1);
	}
	
	public synchronized void genRandomNumber()
	{
		if(valueSet)
		{
			try 
			{
			    wait();	
			} 
			catch (InterruptedException e) 
			{
				// TODO: handle exception
				e.printStackTrace();
			}
		}
		else
		{
			Random r=new Random();
			System.out.println("Thread::"+Thread.currentThread().getName());
			rnum=r.nextInt(10);
			System.out.println("Generated Random Number"+rnum);
			valueSet=true;
			notify();
		}
	}
	
}
