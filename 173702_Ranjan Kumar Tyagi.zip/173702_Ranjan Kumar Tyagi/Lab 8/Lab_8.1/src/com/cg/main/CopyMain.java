package com.cg.main;

import com.cg.runnable.CopyDataThread;

public class CopyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		CopyDataThread c=new CopyDataThread();
		Thread t=new Thread(c,"Copy File");
		System.out.println("Started copying file");
		t.start();
	}

}
