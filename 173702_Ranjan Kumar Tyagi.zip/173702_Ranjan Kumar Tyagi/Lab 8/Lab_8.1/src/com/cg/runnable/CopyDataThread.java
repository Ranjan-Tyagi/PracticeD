package com.cg.runnable;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
//import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class CopyDataThread implements Runnable {
	
	int i=1;

	@Override
	public void run() {
		// TODO Auto-generated method stub
		File f=new File("source.txt");
		Scanner sc=null;
		try {
			sc=new Scanner(f);
		} catch (FileNotFoundException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		FileWriter fw=null;
		try {
			fw=new FileWriter("target.txt");
		} catch (IOException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		BufferedWriter bw=new BufferedWriter(fw);
		PrintWriter pw=new PrintWriter(bw);
		sc.useDelimiter("");
		while(sc.hasNext())
		{
			if(i==11)
			{
				System.out.println("10 characters are copied , copying will resume after 5 second");
				i=1;
				try {
					Thread.sleep(5000);
				} catch (InterruptedException e) {
					// TODO: handle exception
					e.printStackTrace();
				}
			}
			pw.print(sc.next());
			pw.flush();
			i++;
		}
		System.out.println("Whole file copied");
		
	}
	
	
	

}
