package com.cg.eis.service;

import java.io.FileNotFoundException;
import java.io.IOException;

import com.cg.eis.bean.Employee;

public interface EmployeeService {

	public Employee employeeDetails();
	public String insuranceScheme(Employee e);
	public void showDetails(Employee e);
	public  void writeToEmployee(Employee[] e) throws IOException;
	public void readFromEmployeeFile() throws FileNotFoundException;
	

	
}
