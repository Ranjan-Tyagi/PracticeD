package com.cg.eis.exception;

public class EmployeeException extends Exception {

private double salary;
public  EmployeeException() {
	
}
public EmployeeException(double salary,String message) {
	super(message);
	this.salary=salary;
}
	@Override
	public String toString() {
		return "AgeException [salary=" + salary + "]";
	}
	
}
