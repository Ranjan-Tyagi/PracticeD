package com.cg.eis.pl;

import java.io.IOException;
import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.EmployeeException;
import com.cg.eis.service.Service;


public class EmployeeMain {

	public static void exp(double salary) throws EmployeeException
	{
		if(salary<=3000)
			throw new EmployeeException(salary,"Salary should be above 3000");
	}
	
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
	//	Account a;
	//	a=new Saving_Account(2000,new Person("Tyagi",6),50000.0);
		
		
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of Employees");
		int n=sc.nextInt();
		Employee e[]=new Employee[n];
		Service s=new Service();
		for(int i=0;i<n;i++)
			e[i]=s.employeeDetails();
		for(int i=0;i<n;i++)
			e[i].setInsuranceScheme(s.insuranceScheme(e[i]));
		System.out.println("Employee Details are:");
		for(int i=0;i<n;i++)
		{
			try
			{
				exp(e[i].getSalary());
			}
			catch(Exception e1)
			{
				s.showDetails(e[i]);
				System.out.println("Message= "+e1.getMessage());
				System.out.println(e);
				e1.printStackTrace();
			}
		}
		for(int i=0;i<n;i++)
			e[i].setInsuranceScheme(s.insuranceScheme(e[i]));
		System.out.println("Employee details are:");
		
		for(int i=0;i<n;i++)
			s.showDetails(e[i]);
        System.out.println("Storing employees in Employee");
        s.writeToEmployee(e);
        s.readFromEmployeeFile();
		
		
	}

	
	
	
	
	
	
	
	
	
	
	
/*    1
e1
50000
Manager  

2
e2
35000
Programmer

3
e3
15000
System_Associate



4000
Clerk

5
e5
6600000
tyagi
*/


}
