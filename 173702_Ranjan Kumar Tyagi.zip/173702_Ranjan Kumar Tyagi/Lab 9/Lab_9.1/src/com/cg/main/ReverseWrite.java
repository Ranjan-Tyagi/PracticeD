package com.cg.main;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class ReverseWrite {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		FileReader fr=new FileReader("aa.txt");
		//BufferedReader br=new BufferedReader(fr);
		FileWriter fw=new FileWriter("aa.txt",true);
	//	BufferedWriter bw=new BufferedWriter(fw);
	//	PrintWriter pw=new PrintWriter(bw);
		System.out.println("File Content are:");
		
		String s="";
		int c;
		while((c=fr.read())!=-1)
		{
			s+=(char)c;
		}
		System.out.println(s);
	
		for(int i=s.length()-1;i>=0;i--)
		{
			if(s.charAt(i)=='\n')
				continue;
	//		pw.print(s.charAt(i));
	//		pw.flush();
			
			fw.write(s.charAt(i));
			fw.flush();
			
		}
		fw.close();
		fr.close();
		System.out.println("Check file now");

	}

}
