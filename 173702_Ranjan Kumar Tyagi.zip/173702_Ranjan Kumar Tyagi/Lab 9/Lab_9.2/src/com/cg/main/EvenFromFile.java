package com.cg.main;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class EvenFromFile {

	public static void main(String[] args)throws IOException {
		// TODO Auto-generated method stub

		FileWriter fw=new FileWriter("number.txt");
		BufferedWriter bw=new BufferedWriter(fw);
		PrintWriter pw=new PrintWriter(bw);
		for(int i=1;i<=10;i++)
		{
			if(i<10)
				pw.print(i+",");
			else
				pw.print(i);
			pw.flush();
		}
	
		File f=new File("number.txt");
		Scanner sc=new Scanner(f);
		System.out.println("Check file to see its contents");
		System.out.println("Even number from the file are");
		int n=0;
		sc.useDelimiter(",");
		while(sc.hasNext())
		{	n=sc.nextInt();
			if(n%2==0)
				System.out.println(n);
		}
		sc.close();
		fw.close();
		
	}

}
