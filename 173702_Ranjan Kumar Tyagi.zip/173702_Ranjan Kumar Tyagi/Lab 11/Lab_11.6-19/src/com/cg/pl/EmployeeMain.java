package com.cg.pl;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.cg.model.Employee;
import com.cg.service.EmployeeService;

public class EmployeeMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		EmployeeService s=new EmployeeService();
		//Lab 11.6
		System.out.println("Sum of Salaries");
		System.out.println(s.sumOfSalaries());
		System.out.println("=============================================================================");
		//Lab 11.7
		System.out.println("Seniormost Employee is:");
		System.out.println(s.seniorEmployee().get().getFirstName());
		Map<Integer,List<Employee>> techCount=s.countDep();
		System.out.println("=============================================================================");
		//Lab 11.8
		System.out.println("Employee count by Department:");
		for(Integer departmentId:techCount.keySet())
		{
			System.out.println(departmentId+":"+techCount.get(departmentId).size());
		}
		System.out.println("=============================================================================");
		Optional<Integer> highest=s.maxEmpByDep();
		//Lab 11.12
		System.out.println("Department with Maximum employees ="+highest.get());
		System.out.println("=============================================================================");
		//Lab 11.19a
		System.out.println("Employees List sorted by Employee Id: ");
		s.sortByEmployeeId().forEach(System.out::println);
		System.out.println("=============================================================================");
		//Lab 11.19b
		System.out.println("Employees List sorted by Department Id: ");
		s.sortByDepartmentId().forEach(System.out::println);
		System.out.println("=============================================================================");
		//Lab 11.19c
		System.out.println("Employees list sorted by First Name ");
		s.sortByFirstName().forEach(System.out::println);
		System.out.println("=============================================================================");
		//Lab 11.10
		System.out.println("Employees Without Department: ");
		s.getEmployeeWithoutDepartment().forEach(System.out::println);
		System.out.println("=============================================================================");
		
	}

}
