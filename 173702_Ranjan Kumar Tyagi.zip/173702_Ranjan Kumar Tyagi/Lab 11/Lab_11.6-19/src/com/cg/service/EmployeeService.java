package com.cg.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import com.cg.model.Employee;
import com.cg.model.EmployeeRepository;

public class EmployeeService {
public double sumOfSalaries()
{
	return EmployeeRepository.getEmployees().stream().collect(Collectors.summingDouble(i->i.getSalary()));
}

public Optional<Employee> seniorEmployee()

{
	return (EmployeeRepository.getEmployees().stream().reduce((a, b)->
	(a.getHireDate().until(LocalDate.now())).getYears()>(b.getHireDate().until(LocalDate.now())).getYears()?a:b));
}

public Map<Integer,List<Employee>> countDep()
{
	Map<Integer,List<Employee>> techCount= EmployeeRepository.getEmployees().stream().filter(e->e.getDepartment()!=null).collect(Collectors.groupingBy(e->
	e.getDepartment().getDepartmentId()));
	
	return techCount;
}

public Optional<Integer> maxEmpByDep()
{
	Map<Integer,List<Employee>> techCount=countDep();
	return techCount.keySet().stream().reduce((a, b)->techCount.get(a).size()>techCount.get(b).size()?a:b);
	//(a.getDepartment().getDepartmentId())-(b.getDepartment().getDepartmentId())).collect(Collectors.toList());
}

public List<Employee> sortByEmployeeId()
{
	return  EmployeeRepository.getEmployees().stream().filter(e->e.getDepartment()!=null).sorted().collect(Collectors.toList());
}

public List<Employee> sortByDepartmentId()
{
	return  EmployeeRepository.getEmployees().stream().filter(e->e.getDepartment()!=null).sorted((a,b)->(a.getDepartment().getDepartmentId())-(b.getDepartment().getDepartmentId())).collect(Collectors.toList());
}

public List<Employee> sortByFirstName()
{
	 return  EmployeeRepository.getEmployees().stream().sorted((a,b)->a.getFirstName().compareTo(b.getFirstName())).collect(Collectors.toList());
}

public List<Employee> getEmployeeWithoutDepartment()
{
	return  EmployeeRepository.getEmployees().stream().filter(e->e.getDepartment()==null).collect(Collectors.toList());
}


}
