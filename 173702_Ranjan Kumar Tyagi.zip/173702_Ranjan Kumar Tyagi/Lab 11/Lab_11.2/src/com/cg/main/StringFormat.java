package com.cg.main;

interface Format
{
	public String stringFormat(String s);
}
public class StringFormat {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Format f=(s)->{
			String p="";
			s.replace("", "");
			for(int i=0;i<s.length();i++)
				p+=s.charAt(i)+" ";
			return p.trim();
		};
		System.out.println(f.stringFormat("tyagi"));
	}

}
