package com.cg.test;

public class Factorial {

	public int factorial(int f)
	{
		if(f<2)
			return 1;
		return f*factorial(f-1);
	}
}
