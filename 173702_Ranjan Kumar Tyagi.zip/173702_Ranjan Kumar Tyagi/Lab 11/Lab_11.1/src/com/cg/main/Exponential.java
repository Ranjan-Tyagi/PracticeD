package com.cg.main;

interface Power
{
	public int exp(int x,int y);
}
public class Exponential {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Power p=(x,y)->{
			int pr=1;
			while(y>0)
			{
				pr*=x;
			    y--;
			 	
			}
			return pr;
		};
		System.out.println(p.exp(5, 4));
	}

}
