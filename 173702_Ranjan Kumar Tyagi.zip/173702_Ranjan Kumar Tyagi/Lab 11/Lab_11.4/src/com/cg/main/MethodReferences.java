package com.cg.main;

interface Name
{
	public void nm(String s);
}
public class MethodReferences {

	String name;
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MethodReferences ob=new MethodReferences();
		Name p1=ob::setName;
		p1.nm("Ranjan");
		Name p2=System.out::print;
		p2.nm(ob.getName());

	}

}
