package com.cg.main;

import java.util.function.BiPredicate;

public class Login {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BiPredicate<String,String> p=(user,pwd)->user.length()>=8&&pwd.length()>=8;
		System.out.println(p.test("scogkjhtt", "tigesdgjr"));

	}

}
