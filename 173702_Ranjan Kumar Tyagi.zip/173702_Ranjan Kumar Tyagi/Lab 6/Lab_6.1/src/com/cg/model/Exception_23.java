package com.cg.model;

public class Exception_23 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
