package com.cg.model;

@SuppressWarnings("serial")
class UserException extends Exception{
	private String name;

	public UserException(String name,String message) {
		super(message);
		this.name = name;
	}

	@Override
	public String toString() {
		return "UserException [name=" + name + "]"+getMessage();
	}
	
}
	

public class PersonName {
 
	public void person(String firstName, String lastName) throws UserException
	{
	
		
			if(firstName==null)
			{
				throw new UserException(firstName,"Invalid FirstName");
			}
			else if(lastName==null)
			{
				throw new UserException(lastName,"Invalid LastName");
				
			}
		//	System.out.println();
			else
			{
				System.out.println("Unidentified Exception");
			}
		System.out.println();
	
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try{
		Person p=new Person("Ranjan kumar",null,'M');
		
		System.out.println("Person Details:");
		System.out.println("________________\n");
		System.out.println("First name: "+p.getFirstName());
		System.out.println("Last name: "+p.getLastName());
		System.out.println("Gender : "+p.getGender());
		PersonName pn=new PersonName();
		pn.person(p.firstName,p.lastName);
		}
		catch(Exception e){
			System.out.println("Exception Occured");
			e.printStackTrace();
			System.out.println(e);
			
		}
		System.out.println("Program Continued........");
	}

	}
