package com.cg.main;

import com.cg.main.Account;
import com.cg.main.AgeException;
import com.cg.main.Current_Account;
import com.cg.main.Person;
import com.cg.main.Saving_Account;

 public class AccountMain
  {

	public static void exp(float age) throws AgeException
	{
		if(age<=15)
			throw new AgeException(age,"Age should be above 15");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Account a;
		a=new Saving_Account(2000,new Person("Tyagi",6),50000.0);
		try
		{
			exp(a.getAccountHolder().getAge());
		}
		catch(Exception e)
		{
			System.out.println("Message= "+e.getMessage());
		}
		
		a.deposit(2000);
		System.out.println(a);
		a=new Current_Account(3000,new Person("Ranjan",6),60000.0);
		try
		{
			exp(a.getAccountHolder().getAge());
		}
		catch(Exception e)
		{
			System.out.println("Message= "+e.getMessage());
			System.out.println(e);
			e.printStackTrace();
		}
		
		
		Saving_Account sa=new Saving_Account(11,new Person("Ranjan",22),20000.00);
		sa.getDetails();
		System.out.println();
		
		sa.setBalance(sa.deposit(12000));
		System.out.println("After depositing 20000");
		sa.getDetails();
		System.out.println();
		
		sa.setBalance(sa.withdraw(20000));
		System.out.println("After withdrawing 20000");
		sa.getDetails();
		System.out.println();
		
		
		Current_Account ca=new Current_Account(22,new Person("Tyagi",23),70000.00);
		ca.getDetails();
		System.out.println();
		
		ca.setBalance(ca.deposit(50000));
		System.out.println("After depositing 50000");
		ca.getDetails();
		System.out.println();
		
		ca.setBalance(ca.withdraw(50000));
		System.out.println("After withdrawing 50000");
		ca.getDetails();
		System.out.println();
		
		
		
		
		

	}

}


