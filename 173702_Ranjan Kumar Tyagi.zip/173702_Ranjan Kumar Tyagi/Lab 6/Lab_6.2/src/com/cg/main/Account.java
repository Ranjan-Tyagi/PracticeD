package com.cg.main;


public class Account {

	long AccountNumber;
	Person AccountHolder;
	double balance;
	public Account(long accountNumber, Person accountHolder, double balance) {
		super();
		AccountNumber = accountNumber;
		AccountHolder = accountHolder;
		this.balance = balance;
	}
	public long getAccountNumber() {
		return AccountNumber;
	}
	public void setAccountNumber(long accountNumber) {
		AccountNumber = accountNumber;
	}
	public Person getAccountHolder() {
		return AccountHolder;
	}
	public void setAccountHolder(Person accountHolder) {
		AccountHolder = accountHolder;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	public double withdraw(double amount)
	{
		System.out.println("Amount after withdraw will be:"+(getBalance()-amount));
		return (balance-amount);
		
	}
	public double deposit(double amount)
	{
		System.out.println("Amount after deposit will be:"+(getBalance()+amount));

		return (balance+amount);
		
	}
	
	void getDetails()
	{
		System.out.println("Account number is:"+AccountNumber);
		System.out.println("Account holder name is:"+AccountHolder);
		System.out.println("Abbount Balance is:"+balance);
		
	}
	@Override
	public String toString() {
		return "Account [AccountNumber=" + AccountNumber + ", AccountHolder="
				+ AccountHolder + ", balance=" + balance + "]";
	}
	
//	public Account(	long AccountNumber,Person AccountHolder,double Balance){
//		
//	}
	
	
}
