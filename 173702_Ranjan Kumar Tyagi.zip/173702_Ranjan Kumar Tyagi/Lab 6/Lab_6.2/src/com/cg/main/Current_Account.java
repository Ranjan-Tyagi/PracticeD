package com.cg.main;



public class Current_Account extends Account {
	private double Overdraft;
	double amount;
	public Current_Account(long accountNumber, Person accountHolder,
			double balance) {
		super(accountNumber, accountHolder, balance);
		// TODO Auto-generated constructor stub
	}

	public double getOverdraft() {
		return Overdraft;
	}
   

	public void setOverdraft(double Overdraft) {
		this.Overdraft = Overdraft;
	}

	public double withdraft(double amount)
	{
		calOverdraft(amount);
		return super.withdraw(amount);
		
	}
	
	public double deposit(double amount)
	{
		
		return super.deposit(amount);
		
	}
	
	public void calOverdraft(double amount)
	{
		
		if(amount>balance);
		Overdraft=(amount-balance)*0.05;
	}
	
	public void getDetails()
	{
		super.getDetails();
		System.out.println("Overdraft:"+Overdraft);
		
	}
		

}
