package com.cg.main;



public class Saving_Account extends Account  {

	final double Min_Balance;
   

	public Saving_Account(long accountNumber, Person accountHolder, double balance) {
		super(accountNumber,accountHolder,balance);
		Min_Balance=500.0;
	}

	public double getMin_Balance() {
		return Min_Balance;
	}

//	public void setMin_Balance(double Min_Balance) {
//		this.Min_Balance = Min_Balance;
//	}
	public double withdraw(double amount)
	{   if((balance-amount)>=500)
	{
		balance=(balance-amount);
		return super.withdraw(balance);
	}
	else
	{
		System.out.println("Minimum Balance is not Maintained.........Withdrawl unsucessful");
		return 0;
	}
		
	}
	public double deposit(double amount)
	{
		System.out.println("Amount after deposit will be:"+(getBalance()+amount));
		return super.deposit(amount);
		
	}
	
	
}
