package com.cg.main;

@SuppressWarnings("serial")
public class AgeException extends Exception{
private float age;

	public AgeException(float age,String message) {
		super(message);
		// TODO Auto-generate
		this.age=age;
		
	}

	@Override
	public String toString() {
		return "AgeException [age=" + age + "]";
	}

	
	
}
