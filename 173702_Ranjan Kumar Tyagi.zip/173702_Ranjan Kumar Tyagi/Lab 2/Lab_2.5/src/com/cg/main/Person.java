	package com.cg.main;

import java.util.Scanner;

	public class Person {

		String firstName;
		String lastName;
		Gender gender;
		long PhoneNumber;
		
		void person()
		{
			
		}
		
		public Person(String firstName, String lastName, Gender gender) {
			super();
			this.firstName = firstName;
			this.lastName = lastName;
			this.gender = gender;
			
		}
		
		
		

		public String getFirstName() {
			return firstName;
		}

		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}

		public String getLastName() {
			return lastName;
		}

		public void setLastName(String lastName) {
			this.lastName = lastName;
		}

		public Gender getGender() {
			return gender;
		}

		public void setGender(Gender gender) {
			this.gender = gender;
		}
		
		public void acceptPhoneNumber()
		{
			System.out.println("Enter your phone number:");
			@SuppressWarnings("resource")
			Scanner sc=new Scanner(System.in);
			PhoneNumber=sc.nextLong();
		}
		
		public void PersonDetails()
		{
			System.out.println();
			System.out.println("Person Details:");
			System.out.println("_______________\n");
			System.out.println("First name: "+getFirstName());
			System.out.println("Last name: "+getLastName());
			System.out.println("Gender : "+getGender());
			System.out.println("Phone number: "+PhoneNumber);
		}


	}


