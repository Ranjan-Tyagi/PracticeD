package com.cg.main;

public enum Gender {
	M,F

}
