package com.cg.main;

public class AcceptNumberCommandLine {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		long a=Long.parseLong(args[0]);
		System.out.println("You have Entered: "+a);
		System.out.println();
		if(a>0)
			System.out.println("Your Number is Positive.");
		else if(a<0)
			System.out.println("Your Number is Negative.");
		else
			System.out.println("Your Number is Zero.");
		

	}

}
