package com.cg.main;

public class PersonName {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Person p=new Person("Ranjan Kumar","Tyagi",'M');
		
		System.out.println("Person Details:");
		System.out.println("________________\n");
		System.out.println("First name: "+p.getFirstName());
		System.out.println("Last name: "+p.getLastName());
		System.out.println("Gender : "+p.getGender());
		
	}

}
