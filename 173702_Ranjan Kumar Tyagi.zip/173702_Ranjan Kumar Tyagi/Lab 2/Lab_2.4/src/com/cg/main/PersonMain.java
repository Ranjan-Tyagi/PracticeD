package com.cg.main;

public class PersonMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Person p=new Person("Ranjan Kumar","Tyagi",'M');
		
		p.acceptPhoneNumber();
		p.PersonDetails();
		
	}

}
