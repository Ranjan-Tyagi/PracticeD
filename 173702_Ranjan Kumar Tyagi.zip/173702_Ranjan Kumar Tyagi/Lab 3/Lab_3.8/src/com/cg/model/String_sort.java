package com.cg.model;

import java.util.Scanner;

public class String_sort {

	public String[] Str_sort(String str[])
	{
		int i,j;
		for(i=0;i<str.length-1;i++)
			for(j=i+1;j<str.length;j++)
		if(str[i].compareToIgnoreCase(str[j])>=0)
		{
			String str1;
			str1=str[i];
			str[i]=str[j];
			str[j]=str1;
		}
		return str;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str[];
		
		String_sort s=new String_sort();
	//	System.out.println("Enter the Array of Strings ");
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of String: ");
		int ch=sc.nextInt();
		str=new String[ch];
		System.out.println("Enter String:");
		for(int k=0;k<ch;k++)
		{
			str[k]=sc.next();
		}
		s.Str_sort(str);
		System.out.println();
		System.out.println("The sorted String Array is:");
		System.out.println("_______________________");
		for(int k=0;k<ch;k++)
		{
			System.out.println(str[k]);
		}

	}

}
