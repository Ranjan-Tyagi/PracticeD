import java.time.ZoneId;
import java.time.ZonedDateTime;


public class Zone{

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ZonedDateTime zdt=ZonedDateTime.now();
		System.out.println("Today's date and time with zone is:"+zdt);
		System.out.println("===============================================================================");
		ZonedDateTime datetimeParis=ZonedDateTime.now(ZoneId.of("Europe/Paris"));
		System.out.println("Today's date and time in Paris is:"+datetimeParis);
	}

}
