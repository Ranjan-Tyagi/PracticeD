package com.cg.main;

public class StringOperation {
	//String str;
	
	public String stringOperation(String str,int c)
	{	
		String s="";
    @SuppressWarnings("unused")
	char x;
		if(c==1)	
		return str+" "+str;
		else if(c==3)
		{
			int j = 0,i;
			s=s+str.charAt(0);
			for(  i=1;i<str.length();i++){
				for( j=0;j<s.length();j++)
					if(str.charAt(i)==s.charAt(j))
						break;
			if(j==s.length())
			{
				s=s+str.charAt(i);
				
			}
			}
			return s;
		}
		else if(c==2||c==4)
		{
			for(int i=0;i<str.length();i++)
			{
				    
					x=str.charAt(i);
					if(i%2==0)
					{
						if(c==2)
						
						s+="#";
						else if(i%2==0)
					    	{
					    		s=s+Character.toUpperCase(str.charAt(i));
					    	}
					    	else
					    		s=s+str.charAt(i);
						
					}
				
					else s+=str.charAt(i);
			}
			return s;
			
		}
		else
		return "Invalid Choice";
		
		
	}
	

}
