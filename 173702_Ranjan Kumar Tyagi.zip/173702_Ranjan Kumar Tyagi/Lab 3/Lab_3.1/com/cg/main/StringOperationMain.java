package com.cg.main;

import java.util.Scanner;

public class StringOperationMain {
	String str;
	

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringOperation s1=new StringOperation();
		String str;
		@SuppressWarnings("resource")
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the String:");
		str=sc.nextLine();
		System.out.println(" 1.Add the String to itself");
		//System.out.println("String is:"+str+""+str);
		System.out.println(" 2.Replace odd positions with #");
		
		System.out.println(" 3.Remove duplicate characters in the String");
		System.out.println(" 4.Change odd characters to upper case");
		
		System.out.println("=============================");
		System.out.print("Enter your choice:");
		int c=sc.nextInt();
		System.out.println(s1.stringOperation(str,c));
	}

}
