/*3.7 : You are asked to create an application for registering the details of jobseeker. The
requirement is:
Username should always end with _job and there should be atleast minimum of 8 characters to the left
of _job. Write a function to validate the same. Return true in case the validation is passed. In case of
validation failure return false.
*/

package com.cg.main;

import java.util.Scanner;

public class NameValidation {
	public boolean Validate(String str)
	{
		if(str.length()>=12 && str.endsWith("_job") )
			return true;
		else
			return false;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	String str;
	int ch = 0;
	NameValidation val=new NameValidation();
     do{
		System.out.println("Enter user name:");
		@SuppressWarnings("resource")
		Scanner sc=new Scanner(System.in);
		str=sc.nextLine();
		
		System.out.println("____________________________________________________\n");
		System.out.println("UserName is: "+str);
		System.out.println("____________________________________________________\n");
		if(val.Validate(str))
			System.out.println("Valid User");
		else
			System.out.println("Invalid User");
		
		System.out.println("Enter 1 to continue and anything to exit......");
		ch=sc.nextInt();
     }while(ch==1);
     System.out.println("__________________________________________________________");
     System.out.println("Program terminated ...............Thank You");
     System.out.println("__________________________________________________________");
	}

}
