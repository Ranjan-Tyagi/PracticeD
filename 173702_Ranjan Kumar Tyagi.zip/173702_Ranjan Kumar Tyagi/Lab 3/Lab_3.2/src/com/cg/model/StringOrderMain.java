package com.cg.model;

import java.util.Scanner;

public class StringOrderMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		StringOrder s=new StringOrder();
		System.out.println("Enter a String:");
		@SuppressWarnings("resource")
		Scanner sc=new Scanner(System.in);
		String s1=sc.next();	
		s.StringCheck(s1);
		
	}

}
