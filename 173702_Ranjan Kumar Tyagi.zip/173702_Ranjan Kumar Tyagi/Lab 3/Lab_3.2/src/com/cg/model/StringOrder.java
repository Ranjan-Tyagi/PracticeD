package com.cg.model;

public class StringOrder {

	String str;
	public void StringCheck(String str)
	{
		int i;
		int x;
	    str=str.toUpperCase();
		for(i=1;i<str.length();i++)
		{
			x=str.charAt(i);
			if(x<str.charAt(i-1))
					break;
						
	    }
		if(i==str.length())
		System.out.println("String is positive");
		else
		{
			System.out.println("String is Not Positive");
		}
			
		
    }
}