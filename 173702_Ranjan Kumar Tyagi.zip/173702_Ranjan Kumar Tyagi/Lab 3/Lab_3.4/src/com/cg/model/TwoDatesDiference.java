package com.cg.model;

import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class TwoDatesDiference {

	public static void main(String[] args) {
		// TODO Auto-generated method stub



		
		@SuppressWarnings("resource")
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter the Date in dd/MM/yyyy format:");
		String str=sc.next();
		@SuppressWarnings("unused")
		DateTimeFormatter date=DateTimeFormatter.ofPattern("dd/MM/yyyy");
		//System.out.println("");
		//LocalDate ld=LocalDate.parse(str,date);
		String ty[]=str.split("/");
		
		System.out.print("Enter the Warantee duration in years and months:");
		int y=sc.nextInt();
		int m=sc.nextInt();
		
		//System.out.println("");
		
	
		System.out.println("____________________________________________\n");
	//	System.out.print("Enter the Warantee duration in years and months");
		if(Integer.parseInt(ty[1])+m>12)
				y++;
		System.out.println(Integer.parseInt(ty[0])+"/"+(m+Integer.parseInt(ty[1]))%12+"/"+(y+Integer.parseInt(ty[2])));
		System.out.println();
	}

}
