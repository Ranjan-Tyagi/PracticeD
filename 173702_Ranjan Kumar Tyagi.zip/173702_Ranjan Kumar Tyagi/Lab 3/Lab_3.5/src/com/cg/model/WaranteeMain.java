package com.cg.model;

import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class WaranteeMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub



		
		@SuppressWarnings("resource")
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter the Date in dd/MM/yyyy format:");
		String str=sc.next();
		@SuppressWarnings("unused")
		DateTimeFormatter date=DateTimeFormatter.ofPattern("dd/MM/yyyy");
		//System.out.println("");
		//LocalDate ld=LocalDate.parse(str,date);
		String ty[]=str.split("/");
	
		System.out.println("Enter the Warantee duration in years and months:");
		System.out.println();
		
		
		int y;
		
		do{
			System.out.print("Enter years:");
		y=sc.nextInt();		
		if(y<0)
		{
			System.out.println("Please enter the valid number of years.......");
		}else
			System.out.println("You have entered: "+y+"years");
		}while(y<0);
		
		System.out.print("Enter months less than 12:");
		int m=sc.nextInt();
		System.out.println("You have entered: "+m+"months");
		System.out.println("Warantee after "+y+"years "+m+"months will be:");
		
		//System.out.println("");
		
	
		System.out.println("____________________________________________\n");
	//	System.out.print("Enter the Warantee duration in years and months");
		if(Integer.parseInt(ty[1])+m>12)
				y++;
		System.out.println(Integer.parseInt(ty[0])+"/"+(m+Integer.parseInt(ty[1]))%12+"/"+(y+Integer.parseInt(ty[2])));
		System.out.println();
	}

}
