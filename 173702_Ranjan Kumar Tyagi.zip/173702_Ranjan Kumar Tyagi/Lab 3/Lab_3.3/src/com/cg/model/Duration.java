package com.cg.model;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
//import java.time.chrono.ChronoLocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Scanner;

public class Duration {

	public static void main(String[] args) {
		// TODO Auto-generated method stub



		
		@SuppressWarnings("resource")
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Date in dd/MM/yyyy format");
		String date=sc.next();
		DateTimeFormatter dt=DateTimeFormatter.ofPattern("dd/MM/yyyy");
		//System.out.println("");
		LocalDate ld=LocalDate.parse(date,dt);
		LocalDate currentTime=LocalDate.now();
		Period p=currentTime.until(ld);
	
		System.out.println("-------------------------------");
		System.out.println("Days-> "+Math.abs(p.get(ChronoUnit.DAYS)));
		System.out.println("Months-> "+Math.abs(p.get(ChronoUnit.MONTHS)));
		System.out.println("Years-> "+Math.abs(p.get(ChronoUnit.YEARS)));
	}

}
