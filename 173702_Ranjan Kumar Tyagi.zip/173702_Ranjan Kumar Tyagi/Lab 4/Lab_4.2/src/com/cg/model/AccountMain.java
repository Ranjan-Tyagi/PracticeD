package com.cg.model;



public class AccountMain {
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Saving_Account sa=new Saving_Account(11,new Person("Ranjan",22),20000.00);
		sa.getDetails();
		System.out.println();
		
		sa.setBalance(sa.deposit(12000));
		System.out.println("After depositing 20000");
		sa.getDetails();
		System.out.println();
		
		sa.setBalance(sa.withdraw(20000));
		System.out.println("After withdrawing 20000");
		sa.getDetails();
		System.out.println();
		
		
		Current_Account ca=new Current_Account(22,new Person("Tyagi",23),70000.00);
		ca.getDetails();
		System.out.println();
		
		ca.setBalance(ca.deposit(50000));
		System.out.println("After depositing 50000");
		ca.getDetails();
		System.out.println();
		
		ca.setBalance(ca.withdraw(50000));
		System.out.println("After withdrawing 50000");
		ca.getDetails();
		System.out.println();
		
		
		
		
		

	}

}
