/* 4.1: Refer the case study 1in Page No: 5 and create Account Class as shown below in class diagram. 
 * Ensure minimum balance of INR 500 in a bank account is available.

 

Figure 14: Association of person with account class

a)	Create Account for smith with initial balance as INR 2000 and for Kathy with initial balance as 3000.(accNum should be auto generated).
b)	Deposit 2000 INR to smith account.
c)	Withdraw 2000 INR from Kathy account.
d)	Display updated balances in both the account.
e)	Generate toString() method.
 */

package com.cg.model;

public class Account_main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Account Smith=new Account(1234, 2000.00, new Person("Smith",25));
		Account Kathy=new Account(4321, 3000.00, new Person("Kathy",23));
		System.out.println("__________________________________________________________________\n");
		Smith.getDetails();
		System.out.println("__________________________________________________________________\n");
		Kathy.getDetails();
		System.out.println("__________________________________________________________________\n");
		
		System.out.println("Account balance after depositing Rs.200 to Smith's Account:");
		//Scanner sc=new Scanner(System.in);
		//double amount=sc.nextDouble();
		Smith.deposit(2000);
		//System.out.println("Amount after depositing 200 will be: "+(deposit));
		System.out.println("__________________________________________________________________");
		System.out.println("Account balance after withdrawing Rs.2000 to Kathy's Account:");
		//Scanner sc=new Scanner(System.in);
		//double amount=sc.nextDouble();
		Kathy.withdraw(20000);
		System.out.println("Re-enter a valid amount:2000");
		Kathy.withdraw(2000);
		System.out.println("__________________________________________________________________");
		System.out.println("Updated Account Information is:");
		System.out.println("__________________________________________________________________");
		System.out.println(Smith);
		System.out.println("__________________________________________________________________\n");
		System.out.println(Kathy);
		System.out.println("__________________________________________________________________\n");

	}

}
