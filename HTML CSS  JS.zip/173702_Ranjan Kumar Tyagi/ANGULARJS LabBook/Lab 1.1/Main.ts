import { Mobile } from "./Mobile";
import { BasicPhone } from "./BasicPhone";
import { SmartPhone } from "./SmartPhone";

let mb:Mobile[]=[ new BasicPhone(101, 'Nokia', 5100, 'Basic Phone'),
                  new SmartPhone(102, 'Xiaomi A2', 17500, 'Smart Phone')];

for(let x of mb)
    x.printMobileDetails();