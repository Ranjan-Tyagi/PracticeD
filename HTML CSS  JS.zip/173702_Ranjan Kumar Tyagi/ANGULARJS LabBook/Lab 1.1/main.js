"use strict";
exports.__esModule = true;
var BasicPhone_1 = require("./BasicPhone");
var SmartPhone_1 = require("./SmartPhone");
var mb = [new BasicPhone_1.BasicPhone(101, 'Nokia', 5100, 'Basic Phone'),
    new SmartPhone_1.SmartPhone(102, 'Xiaomi A2', 17500, 'Smart Phone')];
for (var _i = 0, mb_1 = mb; _i < mb_1.length; _i++) {
    var x = mb_1[_i];
    x.printMobileDetails();
}
