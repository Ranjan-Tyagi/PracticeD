import { Component, OnInit } from '@angular/core';
import { concat } from 'rxjs';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {
  employee = [
    { empId: 1001, empName: "Rahul", empSal: 9000, empDep: "Java" },
    { empId: 1002, empName: "Sachin", empSal: 19000, empDep: "OraApps" },
    { empId: 1003, empName: "Vikash", empSal: 29000, empDep: "BI" },
  ];
  upd = [];
  
  constructor() { }

  ngOnInit() {
    
  }

  add(id, name, sal, dept) {
    console.log(id, name, sal, dept);
    var obj = { empId: id, empName: name, empSal: sal, empDep: dept };
    this.employee.push(obj);
    console.log(this.employee);
    
  }

  update(v) {
    console.log(v);
    this.upd = [];
    this.upd.push(v.empId);
    this.upd.push(v.empName);
    this.upd.push(v.empSal);
    this.upd.push(v.empDep);
    console.log(this.upd);
  }

  updaterow(id, name, sal, dept) {
    for (var i = 0; i < this.employee.length; i++) {
      if (id == this.employee[i].empId) {
        this.employee[i].empName = name;
        this.employee[i].empSal = sal;
        this.employee[i].empDep = dept;
      }
    }
  }

  delete(v) {
    console.log(v);
    for (var i = 0; i < this.employee.length; i++) {
      
      if (v.empId == this.employee[i].empId) {
        var ele = this.employee;
        delete ele[i];
      }
    }
    this.employee = [];
    for (var i = 0; i < ele.length; i++) {
      if (ele[i].empDep.length > 0) {
        this.employee.push(ele[i]);
      }
      

    }
    console.log(this.employee);
  }
}
