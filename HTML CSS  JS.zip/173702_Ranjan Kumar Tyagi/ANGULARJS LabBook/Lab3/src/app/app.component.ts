import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { NgForm, NgModel } from '@angular/forms';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css']
})
export class FormComponent implements OnInit {

  category = ["Grocery", "Mobile", "Electronics", "Cloths"];
  form: NgForm;
  constructor() { }

  ngOnInit() {
  }

  update(form: NgForm) {
    console.log(form.value.id, form.value.prodname, form.value.cost, form.value.gender,
      form.value.category, form.value.box);
    //console.log(this.form.controls['myVar'].value);
  }
}
