export class Employee {
    constructor(
        public id:string,
        public name:string,
        public salary:string,
        public dept:string
    ){}
}