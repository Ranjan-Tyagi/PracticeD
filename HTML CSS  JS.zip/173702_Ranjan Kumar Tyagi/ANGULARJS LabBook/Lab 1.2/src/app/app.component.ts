import { Component, OnInit } from '@angular/core';
import { Employee } from './employee';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'employee';
  e1=new Employee(" ", " "," " , " ");
  
  constructor(){

  }
  ngOnInit(){

  }
  get emp() { 
    return JSON.stringify(this.e1);
   }
   onSubmit(){
     alert(JSON.stringify(this.e1));
   }
}
