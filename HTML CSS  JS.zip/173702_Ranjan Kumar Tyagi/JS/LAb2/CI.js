
function Interest(Principal,Rate,period)
{

//TODO: display the contents of the variable "msg"
 
var interest;
var x;
var y;
x=(1+(Rate/100));
y=Math.pow(x,period);


//TODO: display the addition of two numbers
interest=(Principal*y)-Principal;
document.write("<pre>");
document.write(" Comp Interest           -        "+interest );
document.write("</pre>");

}
