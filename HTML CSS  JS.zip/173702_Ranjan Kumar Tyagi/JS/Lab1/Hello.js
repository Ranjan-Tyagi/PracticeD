function dispHello()
{
//TODO:return the string “Hello World“
document.write("<b><code>Hello World</code></b>")
}
