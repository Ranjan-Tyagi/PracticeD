var msg;
msg="<p>The actual script is in external script file called<br/> ''common.js''</p>";

function addNos(headVar,bodyVar)
{

//TODO: display the contents of the variable "msg"
document.write(msg); 
var add;



//TODO: display the addition of two numbers
add=headVar+bodyVar;
document.write("The sum of the variables <i>headVar</i> and <i>bodyVar</i> is <b>"+add+"</b>" );

}
