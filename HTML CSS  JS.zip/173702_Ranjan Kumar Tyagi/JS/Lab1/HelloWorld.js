function sayHello()
{
//TODO:return the string “Hello World“
document.write("<b>Hello World</b>")
}
